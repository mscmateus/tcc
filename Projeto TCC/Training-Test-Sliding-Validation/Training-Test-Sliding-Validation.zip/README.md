# Training-Test-Sliding-Validation
extension for the weka tool based on the sliding window method, able to perform the evaluation of predictive algorithms through percentages, absolute number of instances and interval between dates.

This is just the beginning, I believe that community support can further evolve the extension making it the best and greatest choice for evaluation of predictive algorithms!!.
